const { ActivityType } = require('discord.js')

module.exports = {
	name: 'ready',
	once: true,
	execute(client) {
		console.log(`[~] Logged in as ${client.user.username} with the ID ${client.user.id} on ${client.guilds.cache.size} cached servers.`);
		client.user.setPresence({
			activities: [{ name: 'Memes', type: ActivityType.Watching }],
			status: 'online',
		});
	}
}