const { SlashCommandBuilder, TextChannel, PermissionFlagsBits, EmbedBuilder, AttachmentBuilder } = require('discord.js');
const client = require('../../index').client;
const meme = require('meme-search')

module.exports = {
    data: new SlashCommandBuilder()
    .setName("meme")
    .setDescription("Search for a meme")
    .addStringOption(o => 
        o.setName("query")
        .setDescription("Your search query")
        .setRequired(true)
    ),

    async execute(inter){
        const q  = inter.options.getString("query");

        await meme(`${q}`, {
            subreddit: "memes"
        }, (err, res) => {

            if(res.length <= 0) return inter.reply("No memes were found for this query")

            const random = Math.floor(Math.random() * res.length)
            
            inter.reply({ files: [res[random].image_url] })
        })
    }
}